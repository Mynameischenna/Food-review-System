package com.example.empowerproject.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.empowerproject.model.Employee;
import com.example.empowerproject.model.Food;
import com.example.empowerproject.repository.EmployeeRepository;

@Service
public class EmployeeService implements UserDetailsService
{
	@Autowired
	
	private EmployeeRepository er;
	
//	public Employee readbyid(Integer id)
//	{
//		Optional<Employee> temp = er.findById(id);
//		Employee f=null;
//		if(temp.isPresent())
//		{
//			f=temp.get();
//		}
//		return f;
//		
//	}
	public Employee create(Employee e)
	{
		return er.save(e);
	}
	public Employee update(Employee e)
	{
		Optional<Employee> temp = er.findByName(e.getName());
		Employee emp=null;
		if(temp.isPresent())
		{
			emp = e;
			er.save(emp);
		}
		return emp;
	}
	
	public List<Employee> read()
	{
		return er.findAll();
	
    }
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		System.out.println("EmployeeService:loadUserByUsername method: username received is:"+username);
		Optional<Employee> temp = er.findByName(username);
		User user=null;
		if(temp.isPresent())
		{
			Employee e = temp.get();
			user=new User(e.getName(),e.getPassword(),new ArrayList<>());
		}
		System.out.println("what it returns is :");
		System.out.println(user);
		return user;
	}
	
//	public Employee delete(Integer id) {
//		Employee temp= readbyid(id);
//		if(temp!=null)
//		{
//			er.delete(temp);
//		}
//		return temp;
//	}
	public Employee findByUsername(String username)
	{
		Optional<Employee> temp = er.findByName(username);
		Employee user=null;
		if(temp.isPresent())
		{
			user=temp.get();
		}
		return user;
	}
	
}