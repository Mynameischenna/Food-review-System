package com.example.empowerproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.empowerproject.model.Food;
import com.example.empowerproject.model.Rating;
import com.example.empowerproject.service.RatingService;

@RestController
@CrossOrigin("*")
@RequestMapping("/rating")

public class RatingController {
	@Autowired
	private RatingService rs;
	@GetMapping
	public  List<Rating> readal()
	{
		return rs.readall();
	}
	@GetMapping("/{id}")
	public Rating readbyid(@PathVariable("id") Integer id)
	{
		return rs.readbyid(id);
	}
	@PostMapping
	public Rating add(@RequestBody Rating rating)
	{
		return rs.add(rating);
	}
	@PutMapping
	public Rating update(@RequestBody Rating rating)
	{
		return rs.update(rating);
	}
	@DeleteMapping("/{id}")
	public void delete(@PathVariable("id") Integer id)
	{
		rs.delete(id);
	}

}
