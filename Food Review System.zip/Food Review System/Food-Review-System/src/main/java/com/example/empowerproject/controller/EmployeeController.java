package com.example.empowerproject.controller;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.empowerproject.model.Employee;
import com.example.empowerproject.model.Food;
import com.example.empowerproject.service.EmployeeService;
import com.example.empowerproject.service.FoodService;
import com.example.empowerproject.util.AuthRequest;
import com.example.empowerproject.util.JwtUtil;
import com.example.empowerproject.util.MyToken;

import io.jsonwebtoken.Jwt;

@RestController
@RequestMapping("/employee")
@CrossOrigin("*")
public class EmployeeController {
	
	@Autowired
	private EmployeeService fos;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	private AuthenticationManager am;
	
	@GetMapping("/all")
	public  List<Employee> readal()
	{
		return fos.read();
	}
//	@GetMapping("/{id}")
//	public Employee readbyid(@PathVariable("id") Integer id)
//	{
//		return fos.readbyid(id);
//	}
	
	@PostMapping("/login")
	public MyToken validateLogin(@RequestBody AuthRequest ar) throws NoSuchAlgorithmException
	{
	//ystem.out.println(ar);
		String password  = ar.getPassword();
		
		String encodedPassword = encryptSha1(password);
		
//MyToken myToken=new MyToken();
		try
		{
	//System.out.println("Line 41");
			am.authenticate(new UsernamePasswordAuthenticationToken(ar.getUsername(), encodedPassword));
			String token = jwtUtil.generateToken(ar.getUsername());
//	UserDetails user = fos.loadUserByUsername(ar.getUsername());
			
			MyToken myToken = new MyToken();
//			if(user.getPassword().equals(ar.getPassword()))
//			{
//			System.out.println("Line 42");
//			String token = jwtUtil.generateToken(ar.getUsername());
//			System.out.println("Line 43");
////			myToken.token=token;
			myToken.setToken(token);
			return myToken;
		}catch(Exception ex)
		{
			System.out.println("Inside catch block"+ex);
			MyToken myToken = new MyToken();
//			myToken.token="Login failed";
			myToken.setToken("Login failed");
			return myToken;
		}
		
	}
	
	@PostMapping("/signup")
	public Employee signup(@RequestBody Employee employee)
	{
		try {
		String encodedPassword = 	encryptSha1(employee.getPassword());
		employee.setPassword(encodedPassword);
		} catch(NoSuchAlgorithmException e) {
			
		}
		System.out.println(employee);
		return fos.create(employee);
	}
	@PutMapping("/update")
	public Employee update(@RequestBody Employee employee)
	{
		return fos.update(employee);
	}
	
	public String encryptSha1(String password) throws NoSuchAlgorithmException{
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		byte[] hashInBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));
		
		StringBuilder sb = new StringBuilder();
		for (byte b : hashInBytes) {
			sb.append(String.format("%02x",b));
		}
		return sb.toString();
}
//	@DeleteMapping("/{id}")
//	public Employee DeleteEmployee(@PathVariable("id") Integer id) {
//		return fos.delete(id);
//	}
	@GetMapping("/user/{username}")
	public Employee findUserByUsername(@PathVariable("username")String username)
	{
		return fos.findByUsername(username);
	}
}
