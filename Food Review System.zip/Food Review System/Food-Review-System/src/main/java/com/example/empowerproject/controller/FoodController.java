package com.example.empowerproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.empowerproject.model.Food;
import com.example.empowerproject.service.FoodService;

@RestController
@CrossOrigin("*")
@RequestMapping("/food")
public class FoodController {
	
	@Autowired
	private FoodService fos;
	 @GetMapping("/{category}")
	    public List<Food> getBreakfastMenuItems(@PathVariable("category") String category) {
	        return fos.getMenuItemsByCategory(category);
	    }
	
	@GetMapping
	public  List<Food> readal()
	{
		return fos.readall();
	}
	@GetMapping("/{id}")
	public Food readbyid(@PathVariable("id") Integer id)
	{
		return fos.readbyid(id);
	}
	@PostMapping
	public Food add(@RequestBody Food food)
	{
		return fos.add(food);
	}
	@PutMapping
	public Food update(@RequestBody Food food)
	{
		return fos.update(food);
	}
	@DeleteMapping("/{id}")
	public Food delete(@PathVariable("id") Integer id)
	{
		System.out.println("error 2");
		return fos.delete(id);
	}
}
