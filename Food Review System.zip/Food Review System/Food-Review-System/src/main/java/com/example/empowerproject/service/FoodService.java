package com.example.empowerproject.service;

import java.util.List;
import java.util.Optional;

import javax.persistence.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.empowerproject.model.Food;
import com.example.empowerproject.repository.FoodRepository;

@Service
public class FoodService {
	@Autowired
	private FoodRepository fr;
	
	public List<Food> getMenuItemsByCategory(String category) {
        return fr.findByCategory(category);
    }
	public List<Food> readall()
	{
		return fr.findAll();
	}
	
	public Food readbyid(Integer id)
	{
		Optional<Food> temp = fr.findById(id);
		Food f=null;
		if(temp.isPresent())
		{
			f=temp.get();
		}
		return f;
		
	}
	
	public Food add(Food food)
	{
		return fr.save(food);
	}
	public Food update(Food food)
	{
		Food readbyid = readbyid(food.getId());
		if(readbyid!=null)
		{
			fr.save(food);
		}
		return readbyid;
	}
	
	public Food delete(Integer id)
	{
		Food temp=readbyid(id);
		if(temp!=null)
		{
			fr.delete(temp);
		}
		System.err.println("error3");
		return temp;
	}

}
