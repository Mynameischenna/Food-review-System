package com.example.empowerproject.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.empowerproject.model.Food;
import com.example.empowerproject.model.Rating;
import com.example.empowerproject.repository.RatingRepository;

@Service
public class RatingService {
	@Autowired
	private RatingRepository rr;
	public List<Rating> readall()
	{
		return rr.findAll();
	}
	
	public Rating readbyid(Integer id)
	{
		Optional<Rating> temp = rr.findById(id);
		Rating f=null;
		if(temp.isPresent())
		{
			f=temp.get();
		}
		return f;
		
	}
	
	public Rating add(Rating rating)
	{
		return rr.save(rating);
	}
	public Rating update(Rating rating)
	{
		Rating readbyid = readbyid(rating.getId());
		if(readbyid!=null)
		{
			rr.save(rating);
		}
		return readbyid;
	}
	
	public Rating delete(Integer id)
	{
		Rating temp=readbyid(id);
		if(temp!=null)
		{
			rr.delete(temp);
		}
		return temp;
	}

}
