package com.example.empowerproject.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;

@Entity
public class Food {
	@Id
	private Integer id;
	private String food_name;
	private String category;
	private String date;
	@Lob
	@Column(columnDefinition = "text")
	private String picture;
	
	
	public  Food()
	{
		
	}


	public String getPicture() {
		return picture;
	}


	public void setPicture(String picture) {
		this.picture = picture;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getFood_name() {
		return food_name;
	}


	public void setFood_name(String food_name) {
		this.food_name = food_name;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getDate() {
		return date;
	}


	


	@Override
	public String toString() {
		return "Food [id=" + id + ", food_name=" + food_name + ", category=" + category + ", date=" + date
				+ ", picture=" + picture + "]";
	}


	public void setDate(String date) {
		this.date = date;
	}


	public Food(Integer id, String food_name, String category, String date,String picture) {
		super();
		this.id = id;
		this.food_name = food_name;
		this.category = category;
		this.date = date;
		this.picture=picture;
	}
	
	
	
}
