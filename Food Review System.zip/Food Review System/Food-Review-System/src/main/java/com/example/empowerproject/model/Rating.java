package com.example.empowerproject.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Rating {
	@Id
	private Integer id;
	private String food_name;
	private Integer rating;
	
	public Rating()
	{
		
	}
	public Rating(Integer id, String food_name, Integer rating) {
		super();
		this.id = id;
		this.food_name = food_name;
		this.rating = rating;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFood_name() {
		return food_name;
	}
	public void setFood_name(String food_name) {
		this.food_name = food_name;
	}
	public Integer getRating() {
		return rating;
	}
	public void setRating(Integer rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "Rating [id=" + id + ", food_name=" + food_name + ", rating=" + rating + "]";
	}
	

}
