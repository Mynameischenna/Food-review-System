
import './App.css';
import './MenuHeader.css';
// import './style1.css';
import { ButtonContainer, ImageContainer, LogoutIcon } from './Components/ButtonContainer';
import Background from './Components/Background';

import { CustomerRating } from './Components/CustomerRating';
// import ImageSlider from './Components/ImageSlider';
// import { CustomerRating } from './Components/CustomerRating';

import ProductForm  from './Components/ProductForm';
import { ProductGrid } from './Components/ProductGrid';
// import Signin from './Components/Signin';

import StarRating from './Components/StarRating';
import Login from './Components/Login';
import SignUp from './Components/SignUp';
// import FoodItems from './FoodItems';
// import { Route, Routes } from 'react-router-dom';
import Footer from './Components/Footer';
import ImageSlider from './ImageSlider';
import './ImageSlider.css';
import { Routes,Route } from 'react-router-dom';
import MenuHeader from './Components/MenuHeader';
import Menu from './Components/Menu';
import Error from './Components/Error';
import { HomeMenu } from './Components/HomeMenu';
import Admin from './Components/Admin';
import SignIn from './Components/SignIn';
import FoodAverageRatings from './Components/FoodAverageRatings';
import DummyFoodRatings from './Components/DummyFoodRatings';


// import Home from './Home';
const images = [
  'food1.jpg',
  'food2.jpg',
  'food3.jpg',
  // Add more image URLs as needed
];
function App() {
  return (
    <div className="App">
     
     {/* <CustomerRating/> */}
     {/* <Home/> */}
     
     <div className="App">
      {/* <div class="p-5 container-fluid text-center text-white bg-dark">
        <h1>Welcome </h1>
      </div> */}
     
      <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-4">
          {/* <ProductForm /> */}
          {/* <ProductGrid/> */}
           {/* <Login/> */}
          {/* <SignUp/> */}
          {/* <Login/> */}
          <div>
      
      
    </div>
          {/* <FoodItems/> */}
          {/* <LandingPage/> */}
          {/* <CustomerRating/> */}
        </div>
        <div class="col-sm-4"></div>
      </div>
      {/* <div class="row"> */}
        {/* <div class="col-sm-2">
          
        </div> */}
        {/* <div class="col-sm-8">
          {/* <ProductGrid /> */}
        </div>
        
        {/* <div class="col-sm-2">
          <br/>
          
        </div> */}
      {/* </div>

    </div> */}
    {/* />
     */}
      {/* <div>
      <ButtonContainer />
      <ImageContainer />
      <LogoutIcon />
    </div> */}
    
    {/* <ResponsiveAppBar/> */}
    {/* <div className='App'><MenuHeader/></div> */}
    
    <Routes>

      <Route path="/" element={<ImageSlider images={images} />}></Route>
      <Route path="/home" element={<div>
      <ButtonContainer />
      <ImageContainer />
      <LogoutIcon />
    </div>}></Route>
      <Route  path="/login" element={<Login/>}></Route>
      

      <Route path="/productform" element={<ProductForm/>}></Route>
      <Route path='/menu' element={<HomeMenu/>}></Route>
      <Route path='/admin' element={<ProductForm/>}></Route>
      <Route path='/items' element={<ProductGrid/>}></Route>
      <Route path='/ratingmenu' element={<Menu/>}></Route>
      <Route path='/error' element={<Error/>}></Route>
      <Route path='/signup' element={<SignUp/>}></Route>
      <Route path='hmenu'element={<HomeMenu/>}></Route>
      <Route path='/adminlogin' element={<Admin/>}></Route>
      <Route path='/dummylogin' element={<SignIn/>}></Route>
      <Route path='/avgrate' element={<FoodAverageRatings/>}></Route>
      <Route path='/bar' element={<DummyFoodRatings/>}></Route>
    </Routes>
    {/* <Footer/> */}
    </div>
    
  );
}

export default App;
