import React, { useEffect } from 'react';
import './style1.css';
import { useNavigate } from 'react-router-dom';
const ButtonContainer = () => {
  const navigate = useNavigate();

  useEffect(()=>{
    const toke = localStorage.getItem('token');
    {
      localStorage.getItem('token')
    }
    if (toke == null) {
      // alert("token not found in localStorage")
      navigate("/error")
    } else {
      // alert("Token found")
      // navigate("/home")
    }
  })
  function gotomenu() {

    navigate("/menu")
  }
  function gotorating() {
    navigate("/ratingmenu")
  }
  function gotostats()
  {
    navigate("/avgrate")
  
  }


  return (

    <div className="button-container">
      <button className="button" onClick={gotorating}>Add Review</button>
      <button className="button" onClick={gotomenu}>Menu</button>
      <button className="button" onClick={gotostats}>Statistics</button>
    </div>
  );
};

const ImageContainer = () => {
  return (
    <div className="image-container">
      <img src="image12.jpg" alt="bue" style={{ width: "85%", height: "100%", alignSelf: 'left', marginRight: '15%' }} />
    </div>
  );
};

const LogoutIcon = () => {
  const navigate = useNavigate();
  function gotoland() {
    localStorage.removeItem('token')
    navigate("/")
  }
  // const logout = () => {
  //    window.location.href = "";
  // };

  return (
    <div className="logout-icon">
      <img src="images.png" alt="Logout icon" onClick={gotoland} />
    </div>
  );
};

export { ButtonContainer, ImageContainer, LogoutIcon };