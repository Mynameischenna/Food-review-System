import React, { Component } from 'react'
import EmployeeService from "../Services/EmployeeService"
import Login from './Login';
import './Login.css'
import { Link } from 'react-router-dom';

export default class SignUp extends Component {
  constructor()
  {
    super()
    this.state={"id":1,"name":"chenna","email":"hello@","password":"123","check":false,"role":""}
    this.fnsignup=this.fnsignup.bind(this);
    this.myfunc=this.myfunc.bind(this);

  }
  fnsignup()
  {
    this.setState({ "check": true });
    // alert(JSON.stringify(this.state))
    EmployeeService.signup(this.state).then((response)=>{
      alert("hello "+response.data.name+" Account Created Successfully !!!....Happy Login ")
  }).catch((err)=>{
      alert('Error')
  })
  }
  myfunc(){
    // this.setState({ "check": true });
    var obj=this.state;
    obj.check=true;
    this.setState(obj)
    // alert('jag:'+this.state.check)
    console.log('myfunc called');
    this.history.push('/login');
  }
  render() {
    
    return (
      <div className="" >
      <form>
        {/* <Login/> */}
        <br/>
        <h3>Sign Up</h3>
        <br/>
        <div className="mb-3">
          
          <input
            type="number"
            name='id'
            className="form-control"
            placeholder="id"
            style={{ width: "15%", margin: "0 auto" }}
            onChange={(event)=> this.setState({[event.target.name]:event.target.value})}
          />
        </div>
        <div className="mb-3">
          
          <input type="text"
          name="name"
          style={{ width: "15%", margin: "0 auto" }}
           className="form-control" 
           placeholder="full name" 
           onChange={(event)=> this.setState({[event.target.name]:event.target.value})}
           />
        </div>
        <div className="mb-3">
          
          <input
            type="email"
            name='email'
            style={{ width: "15%", margin: "0 auto" }}
            className="form-control"
            placeholder="Enter email"
            onChange={(event)=> this.setState({[event.target.name]:event.target.value})}
          />
        </div>
        <div className="mb-3">
          
          <input
            type="text"
            style={{ width: "15%", margin: "0 auto" }}
            name='role'
            className="form-control"
            placeholder="Enter role(user/admin)"
            onChange={(event)=> this.setState({[event.target.name]:event.target.value})}
          />
        </div>
        <div className="mb-3">
          
          <input
            type="password"
            name='password'
            style={{ width: "15%", margin: "0 auto" }}
            className="form-control"
            placeholder="Enter password"
            onChange={(event)=> this.setState({[event.target.name]:event.target.value})}
          />
        </div>
        <div className="d-grid">
          <button type="submit" onClick={this.fnsignup} style={{width: "150px", height: "40px",background:"black",color:"white",margin: "auto"}}>
            Sign Up
          </button>
        </div>
        <div> </div>
        <p className="forgot-password text-right">
          Already registered{' '} 
          {/* <button className='btn btn-primary' onClick={this.myfunc}> Login</button> */}
          
          
          <Link to="/login" >go to login</Link>
  
        </p>
      </form>
      </div>
    )
  }
}
// -----------------------------
// import React from "react";
// import * as Components from './Components';
// import EmployeeService from "../Services/EmployeeService";
// import backgroundImage from './login.jpg';

// class Signup extends React.Component {

//   constructor() {
//     super();
//     this.state = {
//         "username": "ramesh",
//         "password": "ramesh@123",
//         "fullName": "ramesh",
//         // "role": "admin",
//         "passwordMatchError": "",
//         "errorMessage":"",
//         "isButtonDisabled": true,
//         //"available":true,
//     };
//     this.fnSignup = this.fnSignup.bind(this);
//     this.fnCheckPasswordMatch = this.fnCheckPasswordMatch.bind(this);
//     this.fnLogin=this.fnLogin.bind(this);
//    // this.checkUsernameAvailability=this.checkUsernameAvailability.bind(this);
// }

//   state = {
//     signIn: true,
//   };

//   toggle = () => {
//     this.setState({
//       signIn: !this.state.signIn,
//     });
//   };

//   fnCheckPasswordMatch() {
//     const { password, confirmPassword } = this.state;
//     if (password !== confirmPassword) {
//         this.setState({ passwordMatchError: "Passwords Should Match" });
//     } else {
//         this.setState({ passwordMatchError: "" });
//     }
// }


//   fnSignup() {
//     if (this.state.password === this.state.confirmPassword) {
//         EmployeeService.signup(this.state).then((response) => {
//             alert("Account Created Successfully......:)")
//         }).catch((err) => {
            
//                 alert('Error');
            
//         });
//     } else {
//         alert(this.state.passwordMatchError);
//     }
// }
// validatePassword = () => {
//   if (this.state.password.length < 8) {
//     this.setState({
//       errorMessage: "Password must be at least 8 characters long.",
//       isButtonDisabled: true
//     });
//   } else {
//     this.setState({
//       errorMessage: "",
//       isButtonDisabled:false
//     });
//   }
// };

// fnLogin()
// {
//       EmployeeService.login(this.state)
//       .then((response)=>{
//           // alert(JSON.stringify(response.data))
//          if(response.data.token=='Login failed')
//          {
//           alert("login failed :(")
//           localStorage.removeItem('token')
//          } else{
//           alert("login Success :)")
//           console.log(response.data.token)
//           localStorage.setItem('token',response.data.token);
         
//           window.location.href='/ReviewPage'
         
//           //find user object by username
//           EmployeeService.findUserByUsername(this.state.username)
//           .then((response)=>{
//               console.log(response.data);
//               localStorage.setItem('user',JSON.stringify(response.data));
//           })
//           .catch((response)=>{
//               console.log(response.data);
//           })
//          }
//       })
//       .catch((err)=>{
//           alert(JSON.stringify(err))
//       })
// }
// // checkUsernameAvailability = async () => {
// //   const available = await UserService.checkUsername(this.state.username);
// //   this.setState({ available });
// // };
// render() {
//     const { signIn ,passwordMatchError, password , errorMessage, isButtonDisabled, available} = this.state;
//     return (
      
//       <Components.Container style={{ backgroundImage: `url(${backgroundImage})` }}>
//         <Components.SignUpContainer signinIn={signIn}>
//           <Components.Form>
//             <Components.Title>Create your Account</Components.Title>
//             <Components.Input type="text" placeholder="Username" name="username" onChange={ (event)=> this.setState({[event.target.name]:event.target.value})  } />
//            {/* {!this.state.available && <p>Username is not available</p>} */}
//             <Components.Input type="password" placeholder="Password" name="password"  onChange={ (event)=> this.setState({[event.target.name]:event.target.value})  } onBlur={this.validatePassword}/>
//             {errorMessage && <p style={{ color: "red", fontWeight: "bold", fontStyle: "italic" }}>{errorMessage}</p>}
//             <Components.Input type="password" placeholder="Confirm Password" name="confirmPassword" onChange={ (event)=> this.setState({[event.target.name]:event.target.value})  } onBlur={this.fnCheckPasswordMatch}/>
//             {passwordMatchError && <p style={{ color: "red", fontWeight: "bold", fontStyle: "italic" }}>{passwordMatchError}</p>}
//             <Components.Input type="text" placeholder="Full Name" name="fullName" onChange={ (event)=> this.setState({[event.target.name]:event.target.value})  }/>
//             {/* <Components.Input type="text" placeholder="Role" onChange={ (event)=> this.setState({[event.target.name]:event.target.value})  }/> */}
//             <Components.Button onClick={this.fnSignup} disabled= {this.isButtonDisabled}>Sign Up</Components.Button>
//           </Components.Form>
//         </Components.SignUpContainer>
//         <Components.SignInContainer signinIn={signIn}>
//           <Components.Form>
//             <Components.Title>Sign in</Components.Title>
//             <Components.Input type="text" placeholder="Username" name="username" onChange={ (event)=> this.setState({[event.target.name]:event.target.value})  }/>
//             <Components.Input type="password" placeholder="Password" name="password" onChange={ (event)=> this.setState({[event.target.name]:event.target.value})  }/>
//             <Components.Anchor href="#">Forgot your password?</Components.Anchor>
//             <Components.Button onClick={this.fnLogin}>Sign In</Components.Button>
//           </Components.Form>
//         </Components.SignInContainer>

//         <Components.OverlayContainer signinIn={signIn}>
//           <Components.Overlay signinIn={signIn}>
//             <Components.LeftOverlayPanel signinIn={signIn}>
//               <Components.Title>Welcome Back!</Components.Title>
//               <Components.Paragraph>
//                 To start rating your food  please login with your personal info
//               </Components.Paragraph>
//               <Components.GhostButton onClick={this.toggle}>
//                 Sign In
//               </Components.GhostButton>
//             </Components.LeftOverlayPanel>

//             <Components.RightOverlayPanel signinIn={signIn}>
//               <Components.Title>Namaste !!</Components.Title>
//               <Components.Paragraph>
//                 Enter Your details and start your journey with us
//               </Components.Paragraph>
//               <Components.GhostButton onClick={this.toggle}>
//                 Sign Up
//               </Components.GhostButton>
//             </Components.RightOverlayPanel>
//           </Components.Overlay>
//         </Components.OverlayContainer>
//       </Components.Container>
//     );
    
//   }
  
// }

// export default Signup;


