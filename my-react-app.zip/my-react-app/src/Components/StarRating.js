import React, { useState, useEffect } from "react";
import { FaStar } from "react-icons/fa";
import Ratingservice from "./RatingService";

const StarRating = (props) => {
  const [rating, setRating] = useState(null);
  const [hover, setHover] = useState(null);
  const [ratings, setRatings] = useState({
    id: "",
    food_name: "",
    rating: ""
  });

  useEffect(() => {
    // Update ratings state when props change
    setRatings({
      ...ratings,
      id: props.id,
      food_name: props.food_name
    });
  }, [props.id, props.food_name]);

  const handleStarClick = (ratingValue) => {
    setRating(ratingValue);

    // Save the rating immediately when a star is clicked
    ratings.rating = ratingValue;
    Ratingservice.addProduct(ratings)
      .then(() => {
        alert("Rating saved");
        // Optionally, you can reload the page or update the UI as needed
      })
      .catch(() => {
        alert("Error saving rating");
      });
  };

  return (
    <div>
      {[...Array(5)].map((_, i) => {
        const ratingValue = i + 1;

        return (
          <div key={i} style={{ display: "inline-block" }}>
            <FaStar
              className="star"
              color={ratingValue <= (hover || rating) ? "#ffc107" : "#e4e5e9"}
              size={25}
              onClick={() => handleStarClick(ratingValue)}
              onMouseEnter={() => setHover(ratingValue)}
              onMouseLeave={() => setHover(null)}
            />
            {/* {ratingValue} */}
          </div>
        );
      })}

      <p>The Rating is {rating}</p>
    </div>
  );
};

export default StarRating;
