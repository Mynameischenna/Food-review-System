import React from "react";
import { useEffect, useState } from "react";
import ProductService from "./ProductService";
import StarRating from "./StarRating";

const Menuu = ({ items }) => {
    const [products, setProducts] = useState([]);
    useEffect(() => {
        //food items
        ProductService.getAllProducts().then((response) => {
            setProducts(response.data)

        })
    }, [])
  return (
    <div className="section-center">
      {products.map((item) => {
        const { id, title, img } = item;
        return (
          <article key={id} className="menu-item">
            <img src={item.picture} alt={title} className="photo" />
            <div className="item-info">
              {/* <header>
                <h4>{title}</h4>
                
                {/* <h4 className="price">{price}</h4> */}
              {/* </header> */} 
              item id:{item.id}<br/>
              items name:{item.food_name}
              <StarRating {...item}/>
              {/* <p className="item-text">{desc}</p> */}
            </div>
          </article>
        );
      })}
      {/* <input type="date" value="date"/> */}
    </div>
  );
};

export default Menuu;
