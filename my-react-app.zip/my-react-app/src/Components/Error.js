import { Button } from "bootstrap"
import { Navigate } from "react-router-dom"
import { useNavigate } from 'react-router-dom';
const Error = () =>
{
    const navigate = useNavigate();
    function error()
    {
        navigate("/login")
    }
    return <div style={{textAlign:"center"}}>
        <h1>Page Not Found</h1><br/>
        <input className="btn btn-dark"type="button" value={"go to login"} onClick={error}/>
    </div>
}
export default Error