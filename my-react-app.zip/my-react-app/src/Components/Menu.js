import React, { useEffect, useState } from "react";
import Men from "./Menuu";
import Categories from "./Categories";
import items from "./data";
import logo from "./logo.JPG";
import Breakfast from "./Breakfast";
import { useNavigate } from "react-router-dom";
// import { Today } from "./Today";

const allCategories = ["", ...new Set(items.map((item) => item.category))];

const Menu = () => {
  const [menuItems, setMenuItems] = useState(items);
  const [activeCategory, setActiveCategory] = useState("all");
  const [categories, setCategories] = useState(allCategories);
  

  const navigate=useNavigate();
  useEffect(()=>{
    const toke = localStorage.getItem('token');
    {
      localStorage.getItem('token')
    }
    if (toke == null) {
      // alert("token not found in localStorage")
      navigate("/error")
    } else {
      // alert("Token found")
      // navigate("/home")
    }
  })

  return (
    <main>
      <section className="menu section">
        <div className="title">
          <img src={logo} alt="logo" className="logo" />
          <h2>REVIEW</h2>
          <div className="underline"></div>
        </div>
        <Breakfast/>
        {/* <Categories
          categories={categories}
          activeCategory={activeCategory}
          filterItems={filterItems}
        /> */}
        <Men items={menuItems} />
      </section>
    </main>
  );
};

export default Menu;
