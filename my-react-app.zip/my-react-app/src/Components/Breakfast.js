import { useEffect, useState } from "react";
import ProductService from "./ProductService";

const Breakfast=()=>

{
    const [ratings, setratings] = useState([]);

    useEffect(() => {
        //food items
        ProductService.getAllProducts().then((response) => {
            setratings(response.data)

        })
    }, [])
    return <div>

    </div>
}
export default Breakfast