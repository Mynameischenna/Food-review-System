import React, { useState } from "react";
import EmployeeService from "../Services/EmployeeService";
import { useNavigate } from "react-router-dom";
import "./Login.css"; // Import a custom CSS file for styling
function Login() {
  const [user, setUser] = useState({ username:"" , password:""});
  const navigate = useNavigate();
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setUser({ ...user, [name]: value });
  };

  const handleLogin = () => {
    EmployeeService.login(user)
      .then((response) => {
        if (response.data.token === "Login failed") {
          alert("Your login attempt has failed.");
          localStorage.removeItem("token");
        } else {
          alert("Token received");
          console.log(response.data.token);
          localStorage.setItem("token", response.data.token);

          EmployeeService.findUserByUsername(user.username)
            .then((response) => {
              console.log(response.data);
              
              if(response.data.role=="admin")
              {
                alert("welcome admin !!")
                navigate("/admin")
              }
              else{
                alert('welcome user!!')
            navigate("/home")}
              localStorage.setItem("user", JSON.stringify(response.data));
            })
            .catch((err) => {
              console.log(err);
            });
        }
      })
      .catch((err) => {
        alert(JSON.stringify(err));
      });
  };

  return (
    <div>
      <br/>
        <h3>Login</h3>
        <br/>
      
      User name:
      <input
        type="text"
        name="username"
        className="form-control"
        onChange={handleInputChange}
        value={user.username}
        style={{ width: "15%", margin: "0 auto" }}
      />
      Password:
      <input
        type="password"
        name="password"
        className="form-control"
        onChange={handleInputChange}
        value={user.password}
        style={{ width: "15%", margin: "0 auto" }}
      />
      <br/>
      <div className="d-grid">
          <button type="submit" onClick={handleLogin} style={{width: "140px", height: "40px",background:"black",color:"white",margin: "auto"}}>
            Login
          </button>
        </div>
      <br />
      
    </div>
  );
}

export default Login;
