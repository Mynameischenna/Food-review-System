import React from "react";
import { FaStar } from "react-icons/fa";
import { Navigate, useNavigate } from "react-router-dom";

const foodData = [
  {
    food_id: 1,
    food_name: "dosa",
    ratings: [4, 5, 3, 4, 5],
    image: "dosa.jpg", // Replace with the actual image URL
  },
  {
    food_id: 2,
    food_name: "idly",
    ratings: [3, 4, 2, 3, 4],
    image: "idly.jpg", // Replace with the actual image URL
  },
  {
    food_id: 3,
    food_name: "biryani",
    ratings: [4, 3, 5, 4, 4],
    image: "biryani.webp", // Replace with the actual image URL
  },
  {
    food_id: 4,
    food_name: "Ragi ball",
    ratings: [4, 4, 5, 3, 4],
    image: "ragi.jpg", // Replace with the actual image URL
  },
  {
    food_id: 5,
    food_name: "German Salad",
    ratings: [4, 2, 3, 4, 4],
    image: "greek salad.jpg", // Replace with the actual image URL
  },
  {
    food_id: 6,
    food_name: "Paneer",
    ratings: [4, 3, 5, 4, 1],
    image: "paneer.jpg", // Replace with the actual image URL
  },
];

const FoodAverageRatings = () => {
  const calculateAverageRating = (ratings) => {
    const totalRating = ratings.reduce((acc, rating) => acc + rating, 0);
    return totalRating / ratings.length;
  };
  const navigate=useNavigate()
  const gotograph=()=>
  {
    navigate("/bar")
  };
  

  return (
    <div >
       <div class="p-5 container-fluid text-center text-white bg-dark"><h2>Average Ratings for Delicious Food</h2>
       </div>
       <input type="button" value="GRAPHS" className="btn btn-dark" onClick={gotograph} style={{
    position: 'absolute',
    top: '100px', // Adjust this value to set the top position
    right: '10px', // Adjust this value to set the right position
  }}></input>
      <ul className="food-list">
        {foodData.map((food) => (
          <li key={food.food_id} className="food-item">
            <img src={food.image} alt={food.food_name} className="food-image" width={200}/>
            <div className="food-details">
              <h2 className="food-name">{food.food_name}</h2>
              <p className="average-rating">
                {calculateAverageRating(food.ratings).toFixed(2)}{" "}
                {renderStars(calculateAverageRating(food.ratings))}
              </p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

const renderStars = (averageRating) => {
  const stars = [];
  for (let i = 1; i <= 5; i++) {
    if (i <= averageRating) {
      stars.push(<FaStar key={i} color="#ffc107" size={20} />);
    } else {
      stars.push(<FaStar key={i} color="#e4e5e9" size={20} />);
    }
  }
  return stars;
};

export default FoodAverageRatings;
