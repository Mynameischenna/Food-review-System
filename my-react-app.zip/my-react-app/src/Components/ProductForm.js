import React, { useState } from 'react';
import ProductService from '../Services/ProductService';
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import './ProductForm.css'; // Import your CSS file
const ProductForm = () => {
  const [formData, setFormData] = useState({
    id: '',
    food_name: '',
    category: '',
    date: '',
    picture: ''
  });

  const [file, setFile] = useState(null);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    setFile(file);

    const reader = new FileReader();
    reader.onload = (e) => {
      setFormData({ ...formData, picture: e.target.result });
    };
    reader.readAsDataURL(file);
  };

  const handleAdd = () => {
    ProductService.addProduct(formData)
      .then(() => {
        alert('Item added');
        window.location.reload(false);
      })
      .catch(() => {
        alert('Error');
      });
  };

  const handleUpdate = () => {
    ProductService.updateProduct(formData)
      .then(() => {
        alert('Item updated');
        window.location.reload(false);
      });
  };

  const handleDelete = () => {
    ProductService.deleteProduct(formData.id)
      .then(() => {
        alert(`${formData.id} item deleted`);
        window.location.reload(false);
      });
  };

  const navigate = useNavigate();

  const handleShow = () => {
    // Show functionality
    navigate('/items');
  };

  const gotoland = () => {
    localStorage.removeItem('token');
    navigate('/');
  };

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token == null) {
      navigate('/error');
    }
  });

  return (
    <div style={{ backgroundColor: 'white' }}>
      <div className="p-5 container-fluid text-center text-white bg-dark">
        <h1>Admin Page</h1>
        <div className="logout-icon">
          <img src="images.png" alt="Logout icon" onClick={gotoland} />
        </div>
      </div>
      <div>
        Id: <input type="number" name="id" className="form-control" onChange={handleInputChange} />
        Date: <input type="date" name="date" className="form-control" onChange={handleInputChange} />
        Food Name: <input type="text" name="food_name" className="form-control" onChange={handleInputChange} />
        Category:
        <select className="form-control" name="category" onChange={handleInputChange}>
          <option value="Breakfast">Breakfast</option>
          <option value="Lunch">Lunch</option>
          <option value="Dinner">Dinner</option>
        </select>
        Image: <input type="file" name="category" className="form-control" onChange={handleImageChange} />
      </div>
      <br />
      <input type="button" value="Add" className="btn btn-info" onClick={handleAdd} />&nbsp;
      <input type="button" value="Update" className="btn btn-warning" onClick={handleUpdate} />&nbsp;
      <input type="button" value="Delete" className="btn btn-danger" onClick={handleDelete} />&nbsp;
      <input type="button" value="Show" className="btn btn-dark" onClick={handleShow} />
      <br />
    </div>
  );
};

export default ProductForm;
