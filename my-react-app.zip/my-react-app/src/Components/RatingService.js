import axios from "axios";

class Ratingservice
{
    URL='http://localhost:8080/rating'

    getAllratings()
    {
        // localStorage.setItem("username","jag")
        // localStorage.removeItem("username")
        // window.location.reload(false)
        return axios.get(this.URL);
    }
    findbycategory(category)
    {
        return axios.get(this.URL+"/"+category)
    }

    findProductById(id)
    {
        return axios.get(this.URL+"/"+id);
    }

    addProduct(product)
    {
        return axios.post(this.URL,product);
    }

    updateProduct(product)
    {
        return axios.put(this.URL,product);
    }

    deleteProduct(id)
    {
        return axios.delete(this.URL+"/"+id);
    }
}
export default new Ratingservice();
