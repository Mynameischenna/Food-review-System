const menu = [
    {
      id: 1,
      title: 'Idly',
      category: 'Breakfast',
      
      img: './images/item-1.jpeg',
    },
      
    {
      id: 2,
      title: 'pulav',
      category: 'Lunch',
    
      img: './images/item-2.jpeg',
      
    },
    {
      id: 3,
      title: 'Chapathi',
      category: 'Dinner',
     
      img: './images/item-3.jpeg',
    },
      
    {
      id: 4,
      title: 'Dosa',
      category: 'Breakfast',
     
      img: './images/item-4.jpeg',
    },
      
    {
      id: 5,
      title: 'GheeRice',
      category: 'Lunch',
      
      img: './images/item-5.jpeg',
      
    },
    {
      id: 6,
      title: 'Paneer',
      category: 'Dinner',
      
      img: './images/item-6.jpeg',
      
    },
    {
      id: 7,
      title: 'Pancakes',
      category: 'Breakfast',
      
      img: './images/item-7.jpeg',
      
    },
    {
      id: 8,
      title: 'sambar',
      category: 'Lunch',
      
      img: './images/item-8.jpeg',
      
    },
    {
      id: 9,
      title: 'RagiMudhe',
      category: 'Dinner',
     
      img: './images/item-9.jpeg',
      
    },
    {
      id: 10,
      title: 'Biryani',
      category: 'Lunch',
     
      img: './images/item-10.jpeg',
      
    },
  
  {
    id: 11,
    title: 'EggRice',
    category: 'Dinner',
   
    img: './images/item-11.jpeg',
    
  },
  
  {
    id: 12,
    title: 'Rasam',
    category: 'Lunch',
   
    img: './images/item-12.jpeg',
    
  },
  
  {
    id: 13,
    title: 'DalTadka',
    category: 'Dinner',
   
    img: './images/item-13.jpeg',
    
  },
  
  ];
  export default menu;
  