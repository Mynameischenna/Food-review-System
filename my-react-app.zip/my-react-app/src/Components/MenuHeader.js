import { useEffect, useState } from "react";
import ProductService from "../Services/ProductService";

const MenuHeader = () => {
  const [selectedMenu, setSelectedMenu] = useState();
  const menus = {
    breakfast: [],
    lunch: ['biryani'],
    dinner: ['curd rice'],
  };
  const [products, setProducts] = useState([]);

  useEffect(() => {
    // Fetch food items from your API or service
    ProductService.getAllProducts().then((response) => {
      setProducts(response.data);
    });
  }, []);

  const handleMenuChange = (menu) => {
    setSelectedMenu(menu);
  };

  const myStyle = {
    backgroundImage: "url('https://media.geeksforgeeks.org/wp-content/uploads/rk.png')",
  };

  return (
    <div className="App" style={myStyle}>
      <header>
        <h1>Our Menu</h1>
        <h5>Mouth Watering Delicacies</h5>
        <div>
          <button onClick={() => handleMenuChange('BreakFast')}>Breakfast</button>
          <button onClick={() => handleMenuChange('lunch')}>Lunch</button>
          <button onClick={() => handleMenuChange('dinner')}>Dinner</button>
          <button onClick={() => handleMenuChange('all')}>Show All</button>
        </div>
      </header>
      <h4>{selectedMenu === 'all' ? 'All Items' : selectedMenu}</h4>
      <ul className="all-items">
        {selectedMenu === 'all' ? (
          <li className="menu-items">
            <div>
              <h4>Breakfast</h4>
              {menus.breakfast.map((item, itemIndex) => (
                <li key={itemIndex}>{item}</li>
                
              ))}
            </div>
            {/* Other menu sections go here */}
          </li>
        ) : (
          products.map((item) => {
            if (item.category === selectedMenu) {
              return (
                <article key={item.id} className="menu-item">
                  <img src={item.picture} alt={item.title} className="photo" />
                  <div className="item-info">
                    <p>Item ID: {item.id}</p>
                    <p>Item Name: {item.food_name}</p>
                    {/* Add more item details as needed */}
                  </div>
                </article>
              );
            }
            return null; // Exclude items that don't match the selected category
          })
        )}
      </ul>
    </div>
  );
};

export default MenuHeader;
