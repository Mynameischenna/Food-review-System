import React, { useState } from "react";
import Ratingservice from "./RatingService"

const Categories = ({ categories }) => {
  const [categoryItems, setCategoryItems] = useState([]);

  const filterItems = (category) => {
    Ratingservice.findbycategory(category)
      .then((response) => {
        setCategoryItems(response.data);
      })
      .catch((error) => {
        console.error("Error fetching items by category:", error);
      });
  };

  return (
    <div className="categories">
      {categories.map((category, index) => (
        <button key={index} onClick={() => filterItems(category)}>
          {category}
        </button>
      ))}
    </div>
  );
};

export default Categories;
