// import React from "react";
// import { Bar } from "react-chartjs-2";
// import { Chart, CategoryScale, LinearScale } from 'chart.js';

// const DummyFoodRatings = () => {
//   const foodData = [
//     { food_id: 1, food_name: "Pizza", rating: 4.5 },
//     { food_id: 2, food_name: "Burger", rating: 3.8 },
//     { food_id: 3, food_name: "Spaghetti", rating: 4.2 },
//     { food_id: 4, food_name: "Sushi", rating: 4.9 },
//     { food_id: 5, food_name: "Salad", rating: 3.5 },
//   ];

//   const averageRatings = foodData.reduce((acc, food) => {
//     if (!acc[food.food_name]) {
//       acc[food.food_name] = { totalRating: 0, ratingCount: 0 };
//     }
//     acc[food.food_name].totalRating += food.rating;
//     acc[food.food_name].ratingCount += 1;
//     return acc;
//   }, {});

//   const foodNames = Object.keys(averageRatings);
//   const averageRatingValues = foodNames.map(
//     (foodName) => averageRatings[foodName].totalRating / averageRatings[foodName].ratingCount
//   );

//   const data = {
//     labels: foodNames,
//     datasets: [
//       {
//         label: "Average Ratings",
//         data: averageRatingValues,
//         backgroundColor: "rgba(75, 192, 192, 0.2)",
//         borderColor: "rgba(75, 192, 192, 1)",
//         borderWidth: 1,
//       },
//     ],
//   };

//   const options = {
//     scales: {
//       y: {
//         beginAtZero: true,
//         max: 5, // Set the max rating scale (5 for 5 stars)
//       },
//     },
//   };

//   return (
//     <div>
//       <h1>Average Ratings of Food Items</h1>
//       <Bar data={data} options={options} />
//     </div>
//   );
// }

// export default DummyFoodRatings;
import React from "react";
import { Bar } from "react-chartjs-2";
import { Chart } from 'chart.js/auto';

const DummyFoodRatings = () => {
  const foodData = [
    { food_id: 1, food_name: "Dosa", rating: 4.5 },
    { food_id: 2, food_name: "Idly", rating: 3.8 },
    { food_id: 3, food_name: "Biryani", rating: 4.2 },
    { food_id: 4, food_name: "Ragi ball", rating: 4.9 },
    { food_id: 5, food_name: "German Salad", rating: 3.5 },
    { food_id: 6, food_name: "Paneer", rating: 3.9 }

  ];

  const averageRatings = foodData.reduce((acc, food) => {
    if (!acc[food.food_name]) {
      acc[food.food_name] = { totalRating: 0, ratingCount: 0 };
    }
    acc[food.food_name].totalRating += food.rating;
    acc[food.food_name].ratingCount += 1;
    return acc;
  }, {});

  const foodNames = Object.keys(averageRatings);
  const averageRatingValues = foodNames.map(
    (foodName) => averageRatings[foodName].totalRating / averageRatings[foodName].ratingCount
  );
  const chartContainerStyle = {
    display: "flex",
    justifyContent: "center", // Center the chart horizontally
    alignItems: "center", // Center the chart vertically
    height: "100vh", // Adjust the height as needed
  };

  const data = {
    labels: foodNames,
    datasets: [
      {
        label: "Average Ratings",
        data: averageRatingValues,
        backgroundColor: "rgba(75, 192, 192, 0.2)",
        borderColor: "rgba(75, 192, 192, 1)",
        borderWidth: 1,
      },
    ],
  };

  const options = {
    scales: {
      y: {
        beginAtZero: true,
        max: 5, // Set the max rating scale (5 for 5 stars)
      },
    },
  };
  const graphStyle = {
    width: "800px", // Set the width of the graph
    height: "500px", // Set the height of the graph
    
  };
  const chartOptions = {
    scales: {
      y: {
        beginAtZero: true,
        max: 5,
        grid: {
          display: true,
          color: "rgba(0, 0, 0, 0.5)",
        },
        ticks: {
          stepSize: 1,
          color: "rgba(0, 0, 0, 0.7)",
        },
        title: {
          display: true,
          text: "Average Rating",
          color: "rgba(0, 0, 0, 0.7)",
        },
      },
      x: {
        title: {
          display: true,
          text: "Food Items",
          color: "rgba(0, 0, 0, 0.7)",
        },
      },
    },
  };

  return (
    <div>
      <h1>Average Ratings of Food Items</h1>
    <div style={chartContainerStyle}>
      
      <div style={graphStyle}>
      <Bar data={data} options={chartOptions} />
      </div>
      
    </div>
    
    </div>
  );
}

export default DummyFoodRatings;
