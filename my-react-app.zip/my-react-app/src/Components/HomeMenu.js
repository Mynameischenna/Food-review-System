import { useEffect, useState } from "react";
import ProductService from "../Services/ProductService";
import { useNavigate } from "react-router-dom";

export const HomeMenu = () => {
    const [products, setProducts] = useState([]);
    const navigate=useNavigate();
    useEffect(() => {
        //food items
        ProductService.getAllProducts().then((response) => {
            setProducts(response.data)

        })
    }, [])
    useEffect(()=>{
        const toke = localStorage.getItem('token');
        {
          localStorage.getItem('token')
        }
        if (toke == null) {
          // alert("token not found in localStorage")
          navigate("/error")
        } else {
          // alert("Token found")
          // navigate("/home")
        }
      })
    
    return(
    //     <div>
    // <div class="row">
    // {/* <div class="col-md-6"></div> */}
    // <div class="col-md-6">
    <div>
        {/* <table class="table table-bordered table-striped table-hover"> */}
        <table class ="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>Name</th><th>Category</th><th>food image</th>
                </tr>
            </thead>
            <tbody>
                {
                    products.map((product) =>
                        <tr>
                            {/* <td>{product.id}</td> */}
                            <td>{product.food_name}</td>
                            <td>{product.category}</td>
                            {/* <td>{product.date}</td> */}
                            <td>
                                <img src={product.picture } width="300" height="150"/></td>
                        </tr>
                    )
                }
            </tbody>
        </table>
    </div>
//     
)
    
}
