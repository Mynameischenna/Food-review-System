import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
      <div>
        <h6>Contact Us</h6>
        <h6>Email: rateus@gmail.com</h6>
        <h8>Phone: +1 (123) 456-7890</h8>

      </div>
        {/* <p> 2023 Your Websi</p> */}
      </div>
    </footer>
  );
};

export default Footer;