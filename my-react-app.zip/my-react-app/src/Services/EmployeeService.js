import axios from "axios";
class EmployeeService 
{
    URL="http://localhost:8080/employee/"
    readbyid(id)
    {
        return axios.get(this.URL,id)
    }
    signup(user)
    {
        alert(JSON.stringify(user))
        return axios.post(this.URL+'signup',user)
    }

    login(user)
    {
        alert(JSON.stringify(user))
        return axios.post(this.URL+'login',user)
        
    }

    findUserByUsername(username)
    {
        let token='';
        token=localStorage.getItem('token');
        if(token==null || token=='')
            return;
        let header={
            'authorization': 'Bearer '+token,
            'Accept' : 'application/json',
            'Content-Type': 'application/json'
        }
        return axios.get(this.URL+"user/"+username,{headers:header});
    }


}
export default new EmployeeService