
// ImageSlider.js
import { useNavigate } from 'react-router-dom'; 
import React, { useState, useEffect } from 'react';
import './ImageSlider.css';
import Footer from './Components/Footer';

const images = [
  'food5.jpg',
  'food6.jpg',
  'food3.jpg',
  'food4.jpg',
  // 'food5.jpa',
  // 'food6.jpa'

  // Add more image URLs as needed
];

const ImageSlider = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentImageIndex((prevIndex) =>
        prevIndex === images.length - 1 ? 0 : prevIndex + 1
      );
    }, 3000); // Change this value (in milliseconds) to adjust the slide interval

    return () => clearInterval(intervalId);
  }, []);
const navigate=useNavigate();
function gottologin()
{
  navigate("/login")
}
function gotosignup()
{
  navigate("/signup")
}
  return (
    <div>
      <div className="App">
    <div class="p-5 container-fluid text-center text-white bg-dark">
      <button style={{float:'right',color:'white'}} onClick={gotosignup}>Sign Up</button>
      <button style={{float:'right',color:'white'}} onClick={gottologin}>Login</button>
      
      <h1 className="mt-6">Welcome</h1>
    </div>
    <div className="image-slider">
      <img
        src={images[currentImageIndex]}
        alt={`Slide ${currentImageIndex + 1}`}
        className="slider-image"
      />
      <Footer/>
    </div>
    </div>
    </div>
    
  );
};

export default ImageSlider;

